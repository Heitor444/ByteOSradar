#!/bin/bash
# Monta a ISO do ByteOS. Rode como root, dentro de um Debian 13 (trixie).
set -euo pipefail

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  live-build debootstrap squashfs-tools xorriso ca-certificates \
  grub-efi-amd64-bin grub-pc-bin mtools dosfstools \
  syslinux syslinux-common isolinux

lb clean || true
lb config
lb build

ls -lh ./*.iso
