# ByteOS

Distro Linux personalizada (base Debian 13 + XFCE), montada com live-build.

## Como montar a ISO (GitHub Actions)
1. Crie um repositório no GitHub e envie estes arquivos.
2. Aba **Actions** > "Montar ISO do ByteOS" > **Run workflow**.
3. Quando terminar (30 a 60 min), baixe o artefato **ByteOS-iso**.

## Como montar no seu PC (Debian/Ubuntu)
    sudo ./build.sh

## Testar
Abra a ISO no VirtualBox ou QEMU, ou grave num pendrive com Ventoy/Balena Etcher.
Login automático: usuário `byte`, senha `live`.

## Onde mudar as coisas
- Programas: config/package-lists/byteos.list.chroot
- Steam e nome do sistema: config/hooks/live/
- Temas e atalhos: config/includes.chroot/
- Idioma, nome e opções da ISO: auto/config
- Dock (Plank): config/includes.chroot/etc/skel/.config/plank/ e etc/dconf/
- Painel de cima: config/includes.chroot/etc/skel/.config/xfce4/
- Wallpaper: config/includes.chroot/usr/share/backgrounds/byteos/
- Menu de boot (splash): extras/ (aplicado pelo build.sh)
