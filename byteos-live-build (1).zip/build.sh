#!/bin/bash
# Monta a ISO do ByteOS. Rode como root, dentro de um Debian 13 (trixie).
set -euo pipefail

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  live-build debootstrap squashfs-tools xorriso ca-certificates librsvg2-bin \
  grub-efi-amd64-bin grub-pc-bin mtools dosfstools \
  syslinux syslinux-common isolinux

lb clean || true
lb config

# --- Menu de boot com a cara do ByteOS (troca o logo e o nome do Debian) ---
if [ -d /usr/share/live/build/bootloaders ]; then
  mkdir -p config/bootloaders
  cp -r /usr/share/live/build/bootloaders/. config/bootloaders/
  find config/bootloaders -type f -name 'splash.png' -exec cp extras/splash.png {} \;
  find config/bootloaders -type f -name 'splash.svg' -exec cp extras/splash.svg {} \;
  grep -rIl 'Debian' config/bootloaders | xargs -r sed -i \
    's/Debian GNU\/Linux/ByteOS/g; s/Debian Live/ByteOS Live/g; s/Debian/ByteOS/g'
fi

lb build

ls -lh ./*.iso
